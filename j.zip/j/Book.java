import java.util.Scanner;

class Book {
    String title;
    String author;
    int price;

    Book(String title, String author, int price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    void display(){
        System.out.println("title: " + title + "Author" + author + "Price" + price);
    }
}


