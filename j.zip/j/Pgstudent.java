import java.util.*;

interface Showable {
    void show();
}

class Person {
    String name;
    String gender;
    String phoneNo;

    public Person(String name, String gender, String phoneNo) {
        this.name = name;
        this.gender = gender;
        this.phoneNo = phoneNo;
    }
}

class Student extends Person {
    String course;
    double score;

    public Student(String name, String gender, String phoneNo, String course, double score) {
        this.course = course;
        this.score = score;
    }
}

class PGStudent extends Student implements Showable {
    String researchArea;
    String guide;

    public PGStudent(String name, String gender, String phoneNo, String course, double score, String researchArea, String guide) {
        super(name, gender, phoneNo, course, score);
        this.researchArea = researchArea;
        this.guide = guide;
    }

    public void show() {
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Phone No: " + phoneNo);
        System.out.println("Course: " + course);
        System.out.println("Score: " + score);
        System.out.println("Research Area: " + researchArea);
        System.out.println("Guide: " + guide);
    }
}

public class PGStudentDemo {
    public static void main(String[] args) {
        
        }
    }

