package geometry.interfaces;
public interface calcArea{
    public dopuble area();
}