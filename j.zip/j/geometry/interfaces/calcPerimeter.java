package geometry.interfaces;
public interface calcPerimeter{
    public double perimeter();
}