import java.util.*;

class Student {
    int rolno;
    String name;
    int marks;

    public Student(int rolno, String name, int marks) {
        this.rolno = rolno;
        this.name = name;
        this.marks = marks;
    }

   
    public Student() {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Roll No: ");
        rolno = sc.nextInt();  
        sc.nextLine(); 

        System.out.print("Name: ");
        name = sc.nextLine();  

        System.out.print("Marks: ");
        marks = sc.nextInt();  
        sc.nextLine();  
    }

   
    public void display() {
        System.out.println("Roll No: " + rolno + ", Name: " + name + ", Marks: " + marks);
    }
}



    

public class Demo {
    public static void main(String[] args) {
        Student s[] = new Student[3]; 

      
        for (int i = 0; i < 3; i++) {
            System.out.println("\nEnter details for student " + (i + 1) + ":");
            s[i] = new Student(); 
        }

        sortStudent(s);
        System.out.println("\nStudent Details:");
        for (int i = 0; i < 3; i++) {
            s[i].display(); 
        }
    }

    public static void sortStudent(Student s[]){
        for(int i=0;i<2;i++)
            {
                for(int j=i+1;j<3;j++){
                    if(s[i].marks<s[j].marks)
                       {
                        Student temp=s[i];
                        s[i]=s[j];
                        s[j]=temp;
                       }
                }
            }
    }
}
