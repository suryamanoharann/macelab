const connection = require('./database.js');
const alterTableQuery = `
  ALTER TABLE users
  ADD COLUMN phone VARCHAR(20);
`;

connection.query(alterTableQuery, (err, results) => { 
  if (err) {
    console.error('Error altering table:', err);
    return;
  }
  console.log('Column "phone" added to the "users" table');
});
