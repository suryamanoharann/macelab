const connection = require('./database.js');
const deleteDataQuery = `
  DELETE FROM users
  WHERE name = 'Neethu'
`;

connection.query(deleteDataQuery, (err, results) => {
  if (err) {
    console.error('Error deleting data:', err);
    return;
  }
  console.log('Data deleted from the "users" table');
});
