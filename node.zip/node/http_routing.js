// Import the HTTP module
const http = require('http');
// Create the server
const server = http.createServer((req, res) => {
 // Set response header
 res.setHeader('Content-Type', 'text/plain');
 // Check the request URL
 if (req.url === '/') {
 res.statusCode = 200;
 res.end('Welcome to the homepage!\n');
 } else if (req.url === '/about') {
 res.statusCode = 200;
 res.end('This is the About page.\n');
 } else {
 res.statusCode = 404;
 res.end('Page not found.\n');
 }
});
// Define the port to listen on
const PORT = 3000;
// Start the server
server.listen(PORT, () => {
 console.log(`Server running at http://localhost:${PORT}/`);
});