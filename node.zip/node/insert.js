const connection = require('./database.js');
const insertDataQuery = `
  INSERT INTO users (name, email, age)
  VALUES ('Neethu', 'neethu.huhu@example.com', 55)
`;

connection.query(insertDataQuery, (err, results) => {
  if (err) {
    console.error('Error inserting data:', err);
    return;
  }
  console.log('Data inserted into the "users" table');
});
