// Import the built-in File System module
const fs = require('fs');
// Define the file to read
const filePath = './sample.txt';
// Read the file asynchronously
fs.readFile(filePath, 'utf8', (err, data) => {
 if (err) {
 console.error('Error reading file:', err.message);
 return;
 }
 console.log('File contents:', data);
});