const connection = require('./database.js');
const updateDataQuery = `
  UPDATE users
  SET age = 101
  WHERE name = 'Neethu'
`;

connection.query(updateDataQuery, (err, results) => {
  if (err) {
    console.error('Error updating data:', err);
    return;
  }
  console.log('Data updated in the "users" table');
});
